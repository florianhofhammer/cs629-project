├─ @electron/get@2.0.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/electron/get
│  ├─ publisher: Samuel Attard
│  ├─ path: /home/shioya/work/konata/node_modules/electron/node_modules/@electron/get
│  └─ licenseFile: node_modules/electron/node_modules/@electron/get/LICENSE
├─ @electron/remote@2.0.8
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/electron/remote
│  ├─ path: /home/shioya/work/konata/node_modules/@electron/remote
│  └─ licenseFile: node_modules/@electron/remote/LICENSE
├─ @sindresorhus/is@4.6.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/is
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: https://sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/electron/node_modules/@sindresorhus/is
│  └─ licenseFile: node_modules/electron/node_modules/@sindresorhus/is/license
├─ @szmarczak/http-timer@4.0.6
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/szmarczak/http-timer
│  ├─ publisher: Szymon Marczak
│  ├─ path: /home/shioya/work/konata/node_modules/electron/node_modules/@szmarczak/http-timer
│  └─ licenseFile: node_modules/electron/node_modules/@szmarczak/http-timer/LICENSE
├─ @types/acorn@4.0.5
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/DefinitelyTyped/DefinitelyTyped
│  ├─ path: /home/shioya/work/konata/node_modules/@types/acorn
│  └─ licenseFile: node_modules/@types/acorn/LICENSE
├─ @types/cacheable-request@6.0.3
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/DefinitelyTyped/DefinitelyTyped
│  ├─ path: /home/shioya/work/konata/node_modules/@types/cacheable-request
│  └─ licenseFile: node_modules/@types/cacheable-request/LICENSE
├─ @types/estree@0.0.39
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/DefinitelyTyped/DefinitelyTyped
│  ├─ path: /home/shioya/work/konata/node_modules/@types/estree
│  └─ licenseFile: node_modules/@types/estree/LICENSE
├─ @types/http-cache-semantics@4.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/DefinitelyTyped/DefinitelyTyped
│  ├─ path: /home/shioya/work/konata/node_modules/@types/http-cache-semantics
│  └─ licenseFile: node_modules/@types/http-cache-semantics/LICENSE
├─ @types/keyv@3.1.4
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/DefinitelyTyped/DefinitelyTyped
│  ├─ path: /home/shioya/work/konata/node_modules/@types/keyv
│  └─ licenseFile: node_modules/@types/keyv/LICENSE
├─ @types/node@16.11.58
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/DefinitelyTyped/DefinitelyTyped
│  ├─ path: /home/shioya/work/konata/node_modules/@types/node
│  └─ licenseFile: node_modules/@types/node/LICENSE
├─ @types/responselike@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/DefinitelyTyped/DefinitelyTyped
│  ├─ path: /home/shioya/work/konata/node_modules/@types/responselike
│  └─ licenseFile: node_modules/@types/responselike/LICENSE
├─ @types/yauzl@2.9.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/DefinitelyTyped/DefinitelyTyped
│  ├─ path: /home/shioya/work/konata/node_modules/@types/yauzl
│  └─ licenseFile: node_modules/@types/yauzl/LICENSE
├─ acorn-dynamic-import@3.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/kesne/acorn-dynamic-import
│  ├─ publisher: Jordan Gensler
│  ├─ email: jordangens@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/acorn-dynamic-import
│  └─ licenseFile: node_modules/acorn-dynamic-import/LICENSE
├─ acorn@5.7.4
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/acornjs/acorn
│  ├─ path: /home/shioya/work/konata/node_modules/acorn
│  └─ licenseFile: node_modules/acorn/LICENSE
├─ ansi-styles@3.2.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/chalk/ansi-styles
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/ansi-styles
│  └─ licenseFile: node_modules/ansi-styles/license
├─ anymatch@2.0.0
│  ├─ licenses: ISC
│  ├─ repository: https://github.com/micromatch/anymatch
│  ├─ publisher: Elan Shanker
│  ├─ url: http://github.com/es128
│  ├─ path: /home/shioya/work/konata/node_modules/anymatch
│  └─ licenseFile: node_modules/anymatch/LICENSE
├─ arr-diff@4.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/arr-diff
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/arr-diff
│  └─ licenseFile: node_modules/arr-diff/LICENSE
├─ arr-flatten@1.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/arr-flatten
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/arr-flatten
│  └─ licenseFile: node_modules/arr-flatten/LICENSE
├─ arr-union@3.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/arr-union
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/arr-union
│  └─ licenseFile: node_modules/arr-union/LICENSE
├─ array-unique@0.3.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/array-unique
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/array-unique
│  └─ licenseFile: node_modules/array-unique/LICENSE
├─ assign-symbols@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/assign-symbols
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/assign-symbols
│  └─ licenseFile: node_modules/assign-symbols/LICENSE
├─ async-each@1.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/paulmillr/async-each
│  ├─ publisher: Paul Miller
│  ├─ url: http://paulmillr.com/
│  ├─ path: /home/shioya/work/konata/node_modules/async-each
│  └─ licenseFile: node_modules/async-each/README.md
├─ atob@2.1.2
│  ├─ licenses: (MIT OR Apache-2.0)
│  ├─ repository: git://git.coolaj86.com/coolaj86/atob.js
│  ├─ publisher: AJ ONeal
│  ├─ email: coolaj86@gmail.com
│  ├─ url: https://coolaj86.com
│  ├─ path: /home/shioya/work/konata/node_modules/atob
│  └─ licenseFile: node_modules/atob/LICENSE
├─ base@0.11.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/node-base/base
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/base
│  └─ licenseFile: node_modules/base/LICENSE
├─ binary-extensions@1.13.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/binary-extensions
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/binary-extensions
│  └─ licenseFile: node_modules/binary-extensions/license
├─ boolean@3.2.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/thenativeweb/boolean
│  ├─ path: /home/shioya/work/konata/node_modules/boolean
│  └─ licenseFile: node_modules/boolean/LICENSE.txt
├─ bootstrap@4.6.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/twbs/bootstrap
│  ├─ publisher: The Bootstrap Authors
│  ├─ url: https://github.com/twbs/bootstrap/graphs/contributors
│  ├─ path: /home/shioya/work/konata/node_modules/bootstrap
│  └─ licenseFile: node_modules/bootstrap/LICENSE
├─ braces@2.3.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/micromatch/braces
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/braces
│  └─ licenseFile: node_modules/braces/LICENSE
├─ buffer-crc32@0.2.13
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/brianloveswords/buffer-crc32
│  ├─ publisher: Brian J. Brennan
│  ├─ email: brianloveswords@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/buffer-crc32
│  └─ licenseFile: node_modules/buffer-crc32/LICENSE
├─ cache-base@1.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/cache-base
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/cache-base
│  └─ licenseFile: node_modules/cache-base/LICENSE
├─ cacheable-lookup@5.0.4
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/szmarczak/cacheable-lookup
│  ├─ publisher: Szymon Marczak
│  ├─ path: /home/shioya/work/konata/node_modules/cacheable-lookup
│  └─ licenseFile: node_modules/cacheable-lookup/LICENSE
├─ cacheable-request@7.0.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/lukechilds/cacheable-request
│  ├─ publisher: Luke Childs
│  ├─ email: lukechilds123@gmail.com
│  ├─ url: http://lukechilds.co.uk
│  ├─ path: /home/shioya/work/konata/node_modules/electron/node_modules/cacheable-request
│  └─ licenseFile: node_modules/electron/node_modules/cacheable-request/LICENSE
├─ chalk@2.4.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/chalk/chalk
│  ├─ path: /home/shioya/work/konata/node_modules/chalk
│  └─ licenseFile: node_modules/chalk/license
├─ chokidar@2.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/paulmillr/chokidar
│  ├─ publisher: Paul Miller
│  ├─ url: https://paulmillr.com
│  ├─ path: /home/shioya/work/konata/node_modules/chokidar
│  └─ licenseFile: node_modules/chokidar/README.md
├─ class-utils@0.3.6
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/class-utils
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/class-utils
│  └─ licenseFile: node_modules/class-utils/LICENSE
├─ clone-response@1.0.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/lukechilds/clone-response
│  ├─ publisher: Luke Childs
│  ├─ email: lukechilds123@gmail.com
│  ├─ url: http://lukechilds.co.uk
│  ├─ path: /home/shioya/work/konata/node_modules/clone-response
│  └─ licenseFile: node_modules/clone-response/LICENSE
├─ co@4.6.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/tj/co
│  ├─ path: /home/shioya/work/konata/node_modules/co
│  └─ licenseFile: node_modules/co/LICENSE
├─ collection-visit@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/collection-visit
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/collection-visit
│  └─ licenseFile: node_modules/collection-visit/LICENSE
├─ color-convert@1.9.3
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/Qix-/color-convert
│  ├─ publisher: Heather Arthur
│  ├─ email: fayearthur@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/color-convert
│  └─ licenseFile: node_modules/color-convert/LICENSE
├─ color-name@1.1.3
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/dfcreative/color-name
│  ├─ publisher: DY
│  ├─ email: dfcreative@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/color-name
│  └─ licenseFile: node_modules/color-name/LICENSE
├─ component-emitter@1.2.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/component/emitter
│  ├─ path: /home/shioya/work/konata/node_modules/component-emitter
│  └─ licenseFile: node_modules/component-emitter/LICENSE
├─ copy-descriptor@0.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/copy-descriptor
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/copy-descriptor
│  └─ licenseFile: node_modules/copy-descriptor/LICENSE
├─ core-util-is@1.0.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/isaacs/core-util-is
│  ├─ publisher: Isaac Z. Schlueter
│  ├─ email: i@izs.me
│  ├─ url: http://blog.izs.me/
│  ├─ path: /home/shioya/work/konata/node_modules/core-util-is
│  └─ licenseFile: node_modules/core-util-is/LICENSE
├─ date-time@2.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/date-time
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/date-time
│  └─ licenseFile: node_modules/date-time/license
├─ debug@2.6.9
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/visionmedia/debug
│  ├─ publisher: TJ Holowaychuk
│  ├─ email: tj@vision-media.ca
│  ├─ path: /home/shioya/work/konata/node_modules/snapdragon/node_modules/debug
│  └─ licenseFile: node_modules/snapdragon/node_modules/debug/LICENSE
├─ debug@4.2.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/visionmedia/debug
│  ├─ publisher: TJ Holowaychuk
│  ├─ email: tj@vision-media.ca
│  ├─ path: /home/shioya/work/konata/node_modules/debug
│  └─ licenseFile: node_modules/debug/LICENSE
├─ decode-uri-component@0.2.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/SamVerschueren/decode-uri-component
│  ├─ publisher: Sam Verschueren
│  ├─ email: sam.verschueren@gmail.com
│  ├─ url: github.com/SamVerschueren
│  ├─ path: /home/shioya/work/konata/node_modules/decode-uri-component
│  └─ licenseFile: node_modules/decode-uri-component/license
├─ decompress-response@6.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/decompress-response
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: https://sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/electron/node_modules/decompress-response
│  └─ licenseFile: node_modules/electron/node_modules/decompress-response/license
├─ deep-is@0.1.3
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/thlorenz/deep-is
│  ├─ publisher: Thorsten Lorenz
│  ├─ email: thlorenz@gmx.de
│  ├─ url: http://thlorenz.com
│  ├─ path: /home/shioya/work/konata/node_modules/deep-is
│  └─ licenseFile: node_modules/deep-is/LICENSE
├─ defer-to-connect@2.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/szmarczak/defer-to-connect
│  ├─ publisher: Szymon Marczak
│  ├─ path: /home/shioya/work/konata/node_modules/electron/node_modules/defer-to-connect
│  └─ licenseFile: node_modules/electron/node_modules/defer-to-connect/LICENSE
├─ define-properties@1.1.4
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/ljharb/define-properties
│  ├─ publisher: Jordan Harband
│  ├─ email: ljharb@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/define-properties
│  └─ licenseFile: node_modules/define-properties/LICENSE
├─ define-property@0.2.5
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/define-property
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/class-utils/node_modules/define-property
│  └─ licenseFile: node_modules/class-utils/node_modules/define-property/LICENSE
├─ define-property@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/define-property
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/base/node_modules/define-property
│  └─ licenseFile: node_modules/base/node_modules/define-property/LICENSE
├─ define-property@2.0.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/define-property
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/define-property
│  └─ licenseFile: node_modules/define-property/LICENSE
├─ detect-node@2.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/iliakan/detect-node
│  ├─ publisher: Ilya Kantor
│  ├─ path: /home/shioya/work/konata/node_modules/detect-node
│  └─ licenseFile: node_modules/detect-node/LICENSE
├─ electron@23.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/electron/electron
│  ├─ publisher: Electron Community
│  ├─ path: /home/shioya/work/konata/node_modules/electron
│  └─ licenseFile: node_modules/electron/LICENSE
├─ end-of-stream@1.4.4
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/mafintosh/end-of-stream
│  ├─ publisher: Mathias Buus
│  ├─ email: mathiasbuus@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/end-of-stream
│  └─ licenseFile: node_modules/end-of-stream/LICENSE
├─ env-paths@2.2.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/env-paths
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/env-paths
│  └─ licenseFile: node_modules/env-paths/license
├─ es6-error@4.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/bjyoungblood/es6-error
│  ├─ publisher: Ben Youngblood
│  ├─ path: /home/shioya/work/konata/node_modules/es6-error
│  └─ licenseFile: node_modules/es6-error/LICENSE.md
├─ escape-string-regexp@1.0.5
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/escape-string-regexp
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/escape-string-regexp
│  └─ licenseFile: node_modules/escape-string-regexp/license
├─ escape-string-regexp@4.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/escape-string-regexp
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: https://sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/matcher/node_modules/escape-string-regexp
│  └─ licenseFile: node_modules/matcher/node_modules/escape-string-regexp/license
├─ eslint-config-riot@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/riot/eslint-config
│  ├─ publisher: Gianluca Guarini
│  ├─ email: gianluca.guarini@gmail.com
│  ├─ url: http://gianlucaguarini.com
│  ├─ path: /home/shioya/work/konata/node_modules/eslint-config-riot
│  └─ licenseFile: node_modules/eslint-config-riot/LICENSE
├─ estree-walker@0.6.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/Rich-Harris/estree-walker
│  ├─ publisher: Rich Harris
│  ├─ path: /home/shioya/work/konata/node_modules/estree-walker
│  └─ licenseFile: node_modules/estree-walker/README.md
├─ expand-brackets@2.1.4
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/expand-brackets
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/expand-brackets
│  └─ licenseFile: node_modules/expand-brackets/LICENSE
├─ extend-shallow@2.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/extend-shallow
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/braces/node_modules/extend-shallow
│  └─ licenseFile: node_modules/braces/node_modules/extend-shallow/LICENSE
├─ extend-shallow@3.0.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/extend-shallow
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/extend-shallow
│  └─ licenseFile: node_modules/extend-shallow/LICENSE
├─ extglob@2.0.4
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/micromatch/extglob
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/extglob
│  └─ licenseFile: node_modules/extglob/LICENSE
├─ extract-zip@2.0.1
│  ├─ licenses: BSD-2-Clause
│  ├─ repository: https://github.com/maxogden/extract-zip
│  ├─ publisher: max ogden
│  ├─ path: /home/shioya/work/konata/node_modules/extract-zip
│  └─ licenseFile: node_modules/extract-zip/LICENSE
├─ fast-levenshtein@2.0.6
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/hiddentao/fast-levenshtein
│  ├─ publisher: Ramesh Nair
│  ├─ email: ram@hiddentao.com
│  ├─ url: http://www.hiddentao.com/
│  ├─ path: /home/shioya/work/konata/node_modules/fast-levenshtein
│  └─ licenseFile: node_modules/fast-levenshtein/LICENSE.md
├─ fd-slicer@1.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/andrewrk/node-fd-slicer
│  ├─ publisher: Andrew Kelley
│  ├─ email: superjoe30@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/fd-slicer
│  └─ licenseFile: node_modules/fd-slicer/LICENSE
├─ fill-range@4.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/fill-range
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/fill-range
│  └─ licenseFile: node_modules/fill-range/LICENSE
├─ for-in@1.0.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/for-in
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/for-in
│  └─ licenseFile: node_modules/for-in/LICENSE
├─ fragment-cache@0.2.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/fragment-cache
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/fragment-cache
│  └─ licenseFile: node_modules/fragment-cache/LICENSE
├─ fs-extra@8.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jprichardson/node-fs-extra
│  ├─ publisher: JP Richardson
│  ├─ email: jprichardson@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/fs-extra
│  └─ licenseFile: node_modules/fs-extra/LICENSE
├─ function-bind@1.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/Raynos/function-bind
│  ├─ publisher: Raynos
│  ├─ email: raynos2@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/function-bind
│  └─ licenseFile: node_modules/function-bind/LICENSE
├─ get-intrinsic@1.1.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/ljharb/get-intrinsic
│  ├─ publisher: Jordan Harband
│  ├─ email: ljharb@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/get-intrinsic
│  └─ licenseFile: node_modules/get-intrinsic/LICENSE
├─ get-stream@5.2.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/get-stream
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: https://sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/extract-zip/node_modules/get-stream
│  └─ licenseFile: node_modules/extract-zip/node_modules/get-stream/license
├─ get-value@2.0.6
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/get-value
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/get-value
│  └─ licenseFile: node_modules/get-value/LICENSE
├─ glob-parent@3.1.0
│  ├─ licenses: ISC
│  ├─ repository: https://github.com/es128/glob-parent
│  ├─ publisher: Elan Shanker
│  ├─ url: https://github.com/es128
│  ├─ path: /home/shioya/work/konata/node_modules/glob-parent
│  └─ licenseFile: node_modules/glob-parent/LICENSE
├─ global-agent@3.0.0
│  ├─ licenses: BSD-3-Clause
│  ├─ repository: https://github.com/gajus/global-agent
│  ├─ publisher: Gajus Kuizinas
│  ├─ email: gajus@gajus.com
│  ├─ url: http://gajus.com
│  ├─ path: /home/shioya/work/konata/node_modules/global-agent
│  └─ licenseFile: node_modules/global-agent/LICENSE
├─ globalthis@1.0.3
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/ljharb/System.global
│  ├─ publisher: Jordan Harband
│  ├─ email: ljharb@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/globalthis
│  └─ licenseFile: node_modules/globalthis/LICENSE
├─ got@11.8.6
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/got
│  ├─ path: /home/shioya/work/konata/node_modules/electron/node_modules/got
│  └─ licenseFile: node_modules/electron/node_modules/got/license
├─ graceful-fs@4.1.15
│  ├─ licenses: ISC
│  ├─ repository: https://github.com/isaacs/node-graceful-fs
│  ├─ path: /home/shioya/work/konata/node_modules/graceful-fs
│  └─ licenseFile: node_modules/graceful-fs/LICENSE
├─ graceful-fs@4.2.4
│  ├─ licenses: ISC
│  ├─ repository: https://github.com/isaacs/node-graceful-fs
│  ├─ path: /home/shioya/work/konata/node_modules/fs-extra/node_modules/graceful-fs
│  └─ licenseFile: node_modules/fs-extra/node_modules/graceful-fs/LICENSE
├─ has-flag@3.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/has-flag
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/has-flag
│  └─ licenseFile: node_modules/has-flag/license
├─ has-property-descriptors@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/inspect-js/has-property-descriptors
│  ├─ publisher: Jordan Harband
│  ├─ email: ljharb@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/has-property-descriptors
│  └─ licenseFile: node_modules/has-property-descriptors/LICENSE
├─ has-symbols@1.0.3
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/inspect-js/has-symbols
│  ├─ publisher: Jordan Harband
│  ├─ email: ljharb@gmail.com
│  ├─ url: http://ljharb.codes
│  ├─ path: /home/shioya/work/konata/node_modules/has-symbols
│  └─ licenseFile: node_modules/has-symbols/LICENSE
├─ has-value@0.3.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/has-value
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/unset-value/node_modules/has-value
│  └─ licenseFile: node_modules/unset-value/node_modules/has-value/LICENSE
├─ has-value@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/has-value
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/has-value
│  └─ licenseFile: node_modules/has-value/LICENSE
├─ has-values@0.1.4
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/has-values
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/unset-value/node_modules/has-values
│  └─ licenseFile: node_modules/unset-value/node_modules/has-values/LICENSE
├─ has-values@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/has-values
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/has-values
│  └─ licenseFile: node_modules/has-values/LICENSE
├─ has@1.0.3
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/tarruda/has
│  ├─ publisher: Thiago de Arruda
│  ├─ email: tpadilha84@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/has
│  └─ licenseFile: node_modules/has/LICENSE-MIT
├─ http-cache-semantics@4.1.0
│  ├─ licenses: BSD-2-Clause
│  ├─ repository: https://github.com/kornelski/http-cache-semantics
│  ├─ publisher: Kornel Lesiński
│  ├─ email: kornel@geekhood.net
│  ├─ url: https://kornel.ski/
│  ├─ path: /home/shioya/work/konata/node_modules/http-cache-semantics
│  └─ licenseFile: node_modules/http-cache-semantics/LICENSE
├─ http2-wrapper@1.0.3
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/szmarczak/http2-wrapper
│  ├─ publisher: Szymon Marczak
│  ├─ path: /home/shioya/work/konata/node_modules/http2-wrapper
│  └─ licenseFile: node_modules/http2-wrapper/LICENSE
├─ inherits@2.0.3
│  ├─ licenses: ISC
│  ├─ repository: https://github.com/isaacs/inherits
│  ├─ path: /home/shioya/work/konata/node_modules/inherits
│  └─ licenseFile: node_modules/inherits/LICENSE
├─ is-accessor-descriptor@0.1.6
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/is-accessor-descriptor
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/is-accessor-descriptor
│  └─ licenseFile: node_modules/is-accessor-descriptor/LICENSE
├─ is-accessor-descriptor@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/is-accessor-descriptor
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/base/node_modules/is-accessor-descriptor
│  └─ licenseFile: node_modules/base/node_modules/is-accessor-descriptor/LICENSE
├─ is-binary-path@1.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/is-binary-path
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/is-binary-path
│  └─ licenseFile: node_modules/is-binary-path/license
├─ is-buffer@1.1.6
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/feross/is-buffer
│  ├─ publisher: Feross Aboukhadijeh
│  ├─ email: feross@feross.org
│  ├─ url: http://feross.org/
│  ├─ path: /home/shioya/work/konata/node_modules/is-buffer
│  └─ licenseFile: node_modules/is-buffer/LICENSE
├─ is-data-descriptor@0.1.4
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/is-data-descriptor
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/is-data-descriptor
│  └─ licenseFile: node_modules/is-data-descriptor/LICENSE
├─ is-data-descriptor@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/is-data-descriptor
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/base/node_modules/is-data-descriptor
│  └─ licenseFile: node_modules/base/node_modules/is-data-descriptor/LICENSE
├─ is-descriptor@0.1.6
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/is-descriptor
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/is-descriptor
│  └─ licenseFile: node_modules/is-descriptor/LICENSE
├─ is-descriptor@1.0.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/is-descriptor
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/base/node_modules/is-descriptor
│  └─ licenseFile: node_modules/base/node_modules/is-descriptor/LICENSE
├─ is-extendable@0.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/is-extendable
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/is-extendable
│  └─ licenseFile: node_modules/is-extendable/LICENSE
├─ is-extendable@1.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/is-extendable
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/extend-shallow/node_modules/is-extendable
│  └─ licenseFile: node_modules/extend-shallow/node_modules/is-extendable/LICENSE
├─ is-extglob@2.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/is-extglob
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/is-extglob
│  └─ licenseFile: node_modules/is-extglob/LICENSE
├─ is-glob@3.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/is-glob
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/glob-parent/node_modules/is-glob
│  └─ licenseFile: node_modules/glob-parent/node_modules/is-glob/LICENSE
├─ is-glob@4.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/is-glob
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/is-glob
│  └─ licenseFile: node_modules/is-glob/LICENSE
├─ is-number@3.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/is-number
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/is-number
│  └─ licenseFile: node_modules/is-number/LICENSE
├─ is-plain-object@2.0.4
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/is-plain-object
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/is-plain-object
│  └─ licenseFile: node_modules/is-plain-object/LICENSE
├─ is-reference@1.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/Rich-Harris/is-reference
│  ├─ publisher: Rich Harris
│  ├─ path: /home/shioya/work/konata/node_modules/is-reference
│  └─ licenseFile: node_modules/is-reference/README.md
├─ is-windows@1.0.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/is-windows
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/is-windows
│  └─ licenseFile: node_modules/is-windows/LICENSE
├─ isarray@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/juliangruber/isarray
│  ├─ publisher: Julian Gruber
│  ├─ email: mail@juliangruber.com
│  ├─ url: http://juliangruber.com
│  ├─ path: /home/shioya/work/konata/node_modules/unset-value/node_modules/isarray
│  └─ licenseFile: node_modules/unset-value/node_modules/isarray/README.md
├─ isobject@2.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/isobject
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/unset-value/node_modules/has-value/node_modules/isobject
│  └─ licenseFile: node_modules/unset-value/node_modules/has-value/node_modules/isobject/LICENSE
├─ isobject@3.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/isobject
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/isobject
│  └─ licenseFile: node_modules/isobject/LICENSE
├─ jquery@3.6.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jquery/jquery
│  ├─ publisher: OpenJS Foundation and other contributors
│  ├─ url: https://github.com/jquery/jquery/blob/3.6.0/AUTHORS.txt
│  ├─ path: /home/shioya/work/konata/node_modules/jquery
│  └─ licenseFile: node_modules/jquery/LICENSE.txt
├─ json-buffer@3.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/dominictarr/json-buffer
│  ├─ publisher: Dominic Tarr
│  ├─ email: dominic.tarr@gmail.com
│  ├─ url: http://dominictarr.com
│  ├─ path: /home/shioya/work/konata/node_modules/electron/node_modules/json-buffer
│  └─ licenseFile: node_modules/electron/node_modules/json-buffer/LICENSE
├─ json-stringify-safe@5.0.1
│  ├─ licenses: ISC
│  ├─ repository: https://github.com/isaacs/json-stringify-safe
│  ├─ publisher: Isaac Z. Schlueter
│  ├─ email: i@izs.me
│  ├─ url: http://blog.izs.me
│  ├─ path: /home/shioya/work/konata/node_modules/json-stringify-safe
│  └─ licenseFile: node_modules/json-stringify-safe/LICENSE
├─ jsonfile@4.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jprichardson/node-jsonfile
│  ├─ publisher: JP Richardson
│  ├─ email: jprichardson@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/jsonfile
│  └─ licenseFile: node_modules/jsonfile/LICENSE
├─ keyv@4.5.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jaredwray/keyv
│  ├─ publisher: Jared Wray
│  ├─ email: me@jaredwray.com
│  ├─ url: http://jaredwray.com
│  ├─ path: /home/shioya/work/konata/node_modules/electron/node_modules/keyv
│  └─ licenseFile: node_modules/electron/node_modules/keyv/README.md
├─ kind-of@3.2.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/kind-of
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/is-number/node_modules/kind-of
│  └─ licenseFile: node_modules/is-number/node_modules/kind-of/LICENSE
├─ kind-of@4.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/kind-of
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/has-values/node_modules/kind-of
│  └─ licenseFile: node_modules/has-values/node_modules/kind-of/LICENSE
├─ kind-of@5.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/kind-of
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/is-descriptor/node_modules/kind-of
│  └─ licenseFile: node_modules/is-descriptor/node_modules/kind-of/LICENSE
├─ kind-of@6.0.3
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/kind-of
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/kind-of
│  └─ licenseFile: node_modules/kind-of/LICENSE
├─ konata@0.39.0
│  ├─ licenses: BSD-3-Clause
│  ├─ repository: https://github.com/shioyadan/Konata
│  ├─ publisher: Ryota Shioya
│  ├─ email: shioya@ci.i.u-tokyo.ac.jp
│  ├─ path: /home/shioya/work/konata
│  └─ licenseFile: LICENSE.md
├─ levn@0.3.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/gkz/levn
│  ├─ publisher: George Zahariev
│  ├─ email: z@georgezahariev.com
│  ├─ path: /home/shioya/work/konata/node_modules/levn
│  └─ licenseFile: node_modules/levn/LICENSE
├─ locate-character@2.0.5
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/Rich-Harris/locate-character
│  ├─ publisher: Rich Harris
│  ├─ path: /home/shioya/work/konata/node_modules/locate-character
│  └─ licenseFile: node_modules/locate-character/README.md
├─ lodash.every@4.6.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/lodash/lodash
│  ├─ publisher: John-David Dalton
│  ├─ email: john.david.dalton@gmail.com
│  ├─ url: http://allyoucanleet.com/
│  ├─ path: /home/shioya/work/konata/node_modules/lodash.every
│  └─ licenseFile: node_modules/lodash.every/LICENSE
├─ lodash.flattendeep@4.4.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/lodash/lodash
│  ├─ publisher: John-David Dalton
│  ├─ email: john.david.dalton@gmail.com
│  ├─ url: http://allyoucanleet.com/
│  ├─ path: /home/shioya/work/konata/node_modules/lodash.flattendeep
│  └─ licenseFile: node_modules/lodash.flattendeep/LICENSE
├─ lodash.foreach@4.5.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/lodash/lodash
│  ├─ publisher: John-David Dalton
│  ├─ email: john.david.dalton@gmail.com
│  ├─ url: http://allyoucanleet.com/
│  ├─ path: /home/shioya/work/konata/node_modules/lodash.foreach
│  └─ licenseFile: node_modules/lodash.foreach/LICENSE
├─ lodash.map@4.6.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/lodash/lodash
│  ├─ publisher: John-David Dalton
│  ├─ email: john.david.dalton@gmail.com
│  ├─ url: http://allyoucanleet.com/
│  ├─ path: /home/shioya/work/konata/node_modules/lodash.map
│  └─ licenseFile: node_modules/lodash.map/LICENSE
├─ lodash.maxby@4.6.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/lodash/lodash
│  ├─ publisher: John-David Dalton
│  ├─ email: john.david.dalton@gmail.com
│  ├─ url: http://allyoucanleet.com/
│  ├─ path: /home/shioya/work/konata/node_modules/lodash.maxby
│  └─ licenseFile: node_modules/lodash.maxby/LICENSE
├─ lowercase-keys@2.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/lowercase-keys
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/electron/node_modules/lowercase-keys
│  └─ licenseFile: node_modules/electron/node_modules/lowercase-keys/license
├─ lru-cache@6.0.0
│  ├─ licenses: ISC
│  ├─ repository: https://github.com/isaacs/node-lru-cache
│  ├─ publisher: Isaac Z. Schlueter
│  ├─ email: i@izs.me
│  ├─ path: /home/shioya/work/konata/node_modules/lru-cache
│  └─ licenseFile: node_modules/lru-cache/LICENSE
├─ map-cache@0.2.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/map-cache
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/map-cache
│  └─ licenseFile: node_modules/map-cache/LICENSE
├─ map-visit@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/map-visit
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/map-visit
│  └─ licenseFile: node_modules/map-visit/LICENSE
├─ matcher@3.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/matcher
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: https://sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/matcher
│  └─ licenseFile: node_modules/matcher/license
├─ micromatch@3.1.10
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/micromatch/micromatch
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/micromatch
│  └─ licenseFile: node_modules/micromatch/LICENSE
├─ mimic-response@1.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/mimic-response
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/mimic-response
│  └─ licenseFile: node_modules/mimic-response/license
├─ mimic-response@3.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/mimic-response
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: https://sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/electron/node_modules/mimic-response
│  └─ licenseFile: node_modules/electron/node_modules/mimic-response/license
├─ mixin-deep@1.3.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/mixin-deep
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/mixin-deep
│  └─ licenseFile: node_modules/mixin-deep/LICENSE
├─ ms@2.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/zeit/ms
│  ├─ path: /home/shioya/work/konata/node_modules/snapdragon/node_modules/ms
│  └─ licenseFile: node_modules/snapdragon/node_modules/ms/license.md
├─ ms@2.1.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/zeit/ms
│  ├─ path: /home/shioya/work/konata/node_modules/ms
│  └─ licenseFile: node_modules/ms/license.md
├─ nanomatch@1.2.13
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/micromatch/nanomatch
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/nanomatch
│  └─ licenseFile: node_modules/nanomatch/LICENSE
├─ normalize-path@2.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/normalize-path
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/anymatch/node_modules/normalize-path
│  └─ licenseFile: node_modules/anymatch/node_modules/normalize-path/LICENSE
├─ normalize-path@3.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/normalize-path
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/normalize-path
│  └─ licenseFile: node_modules/normalize-path/LICENSE
├─ normalize-url@6.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/normalize-url
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: https://sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/electron/node_modules/normalize-url
│  └─ licenseFile: node_modules/electron/node_modules/normalize-url/license
├─ object-copy@0.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/object-copy
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/object-copy
│  └─ licenseFile: node_modules/object-copy/LICENSE
├─ object-keys@1.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/ljharb/object-keys
│  ├─ publisher: Jordan Harband
│  ├─ email: ljharb@gmail.com
│  ├─ url: http://ljharb.codes
│  ├─ path: /home/shioya/work/konata/node_modules/object-keys
│  └─ licenseFile: node_modules/object-keys/LICENSE
├─ object-visit@1.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/object-visit
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/object-visit
│  └─ licenseFile: node_modules/object-visit/LICENSE
├─ object.pick@1.3.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/object.pick
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/object.pick
│  └─ licenseFile: node_modules/object.pick/LICENSE
├─ once@1.4.0
│  ├─ licenses: ISC
│  ├─ repository: https://github.com/isaacs/once
│  ├─ publisher: Isaac Z. Schlueter
│  ├─ email: i@izs.me
│  ├─ url: http://blog.izs.me/
│  ├─ path: /home/shioya/work/konata/node_modules/once
│  └─ licenseFile: node_modules/once/LICENSE
├─ optionator@0.8.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/gkz/optionator
│  ├─ publisher: George Zahariev
│  ├─ email: z@georgezahariev.com
│  ├─ path: /home/shioya/work/konata/node_modules/optionator
│  └─ licenseFile: node_modules/optionator/LICENSE
├─ p-cancelable@2.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/p-cancelable
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/electron/node_modules/p-cancelable
│  └─ licenseFile: node_modules/electron/node_modules/p-cancelable/license
├─ parse-ms@1.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/parse-ms
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: http://sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/parse-ms
│  └─ licenseFile: node_modules/parse-ms/license
├─ pascalcase@0.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/pascalcase
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/pascalcase
│  └─ licenseFile: node_modules/pascalcase/LICENSE
├─ path-dirname@1.0.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/es128/path-dirname
│  ├─ publisher: Elan Shanker
│  ├─ path: /home/shioya/work/konata/node_modules/path-dirname
│  └─ licenseFile: node_modules/path-dirname/license
├─ path-is-absolute@1.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/path-is-absolute
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/path-is-absolute
│  └─ licenseFile: node_modules/path-is-absolute/license
├─ pend@1.2.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/andrewrk/node-pend
│  ├─ publisher: Andrew Kelley
│  ├─ email: superjoe30@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/pend
│  └─ licenseFile: node_modules/pend/LICENSE
├─ posix-character-classes@0.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/posix-character-classes
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/posix-character-classes
│  └─ licenseFile: node_modules/posix-character-classes/LICENSE
├─ prelude-ls@1.1.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/gkz/prelude-ls
│  ├─ publisher: George Zahariev
│  ├─ email: z@georgezahariev.com
│  ├─ path: /home/shioya/work/konata/node_modules/prelude-ls
│  └─ licenseFile: node_modules/prelude-ls/LICENSE
├─ pretty-ms@3.2.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/pretty-ms
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/pretty-ms
│  └─ licenseFile: node_modules/pretty-ms/license
├─ process-nextick-args@2.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/calvinmetcalf/process-nextick-args
│  ├─ path: /home/shioya/work/konata/node_modules/process-nextick-args
│  └─ licenseFile: node_modules/process-nextick-args/license.md
├─ progress@2.0.3
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/visionmedia/node-progress
│  ├─ publisher: TJ Holowaychuk
│  ├─ email: tj@vision-media.ca
│  ├─ path: /home/shioya/work/konata/node_modules/progress
│  └─ licenseFile: node_modules/progress/LICENSE
├─ pump@3.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/mafintosh/pump
│  ├─ publisher: Mathias Buus Madsen
│  ├─ email: mathiasbuus@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/pump
│  └─ licenseFile: node_modules/pump/LICENSE
├─ quick-lru@5.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/quick-lru
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: https://sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/quick-lru
│  └─ licenseFile: node_modules/quick-lru/license
├─ readable-stream@2.3.6
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/nodejs/readable-stream
│  ├─ path: /home/shioya/work/konata/node_modules/readdirp/node_modules/readable-stream
│  └─ licenseFile: node_modules/readdirp/node_modules/readable-stream/LICENSE
├─ readdirp@2.2.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/paulmillr/readdirp
│  ├─ publisher: Thorsten Lorenz
│  ├─ email: thlorenz@gmx.de
│  ├─ url: thlorenz.com
│  ├─ path: /home/shioya/work/konata/node_modules/readdirp
│  └─ licenseFile: node_modules/readdirp/LICENSE
├─ regex-not@1.0.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/regex-not
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/regex-not
│  └─ licenseFile: node_modules/regex-not/LICENSE
├─ remove-trailing-separator@1.1.0
│  ├─ licenses: ISC
│  ├─ repository: https://github.com/darsain/remove-trailing-separator
│  ├─ publisher: darsain
│  ├─ path: /home/shioya/work/konata/node_modules/remove-trailing-separator
│  └─ licenseFile: node_modules/remove-trailing-separator/license
├─ repeat-element@1.1.3
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/repeat-element
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/repeat-element
│  └─ licenseFile: node_modules/repeat-element/LICENSE
├─ repeat-string@1.6.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/repeat-string
│  ├─ publisher: Jon Schlinkert
│  ├─ url: http://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/repeat-string
│  └─ licenseFile: node_modules/repeat-string/LICENSE
├─ require-relative@0.8.7
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/kamicane/require-relative
│  ├─ publisher: Valerio Proietti
│  ├─ email: @kamicane
│  ├─ url: http://mad4milk.net
│  ├─ path: /home/shioya/work/konata/node_modules/require-relative
│  └─ licenseFile: node_modules/require-relative/README.md
├─ resolve-alpn@1.2.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/szmarczak/resolve-alpn
│  ├─ publisher: Szymon Marczak
│  ├─ path: /home/shioya/work/konata/node_modules/resolve-alpn
│  └─ licenseFile: node_modules/resolve-alpn/LICENSE
├─ resolve-url@0.2.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/lydell/resolve-url
│  ├─ publisher: Simon Lydell
│  ├─ path: /home/shioya/work/konata/node_modules/resolve-url
│  └─ licenseFile: node_modules/resolve-url/LICENSE
├─ responselike@2.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/responselike
│  ├─ publisher: lukechilds
│  ├─ path: /home/shioya/work/konata/node_modules/electron/node_modules/responselike
│  └─ licenseFile: node_modules/electron/node_modules/responselike/LICENSE
├─ ret@0.1.15
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/fent/ret.js
│  ├─ publisher: Roly Fentanes
│  ├─ url: https://github.com/fent
│  ├─ path: /home/shioya/work/konata/node_modules/ret
│  └─ licenseFile: node_modules/ret/LICENSE
├─ riot-cli@4.1.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/riot/cli
│  ├─ publisher: Gianluca Guarini
│  ├─ email: gianluca.guarini@gmail.com
│  ├─ url: http://gianlucaguarini.com/
│  ├─ path: /home/shioya/work/konata/node_modules/riot/node_modules/riot-cli
│  └─ licenseFile: node_modules/riot/node_modules/riot-cli/LICENSE
├─ riot-compiler@3.5.3
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/riot/compiler
│  ├─ publisher: Riot maintainers team + smart people from all over the world
│  ├─ path: /home/shioya/work/konata/node_modules/riot-compiler
│  └─ licenseFile: node_modules/riot-compiler/LICENSE
├─ riot-observable@3.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/riot/observable
│  ├─ publisher: Muut, Inc. and other contributors
│  ├─ path: /home/shioya/work/konata/node_modules/riot-observable
│  └─ licenseFile: node_modules/riot-observable/LICENSE
├─ riot-tmpl@3.0.8
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/riot/tmpl
│  ├─ publisher: Riot maintainers team + smart people from all over the world
│  ├─ path: /home/shioya/work/konata/node_modules/riot-tmpl
│  └─ licenseFile: node_modules/riot-tmpl/LICENSE
├─ riot@3.13.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/riot/riot
│  ├─ publisher: Riot maintainers team + smart people from all over the world
│  ├─ path: /home/shioya/work/konata/node_modules/riot
│  └─ licenseFile: node_modules/riot/LICENSE.txt
├─ riotcontrol@0.0.3
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jimsparkman/RiotControl
│  ├─ publisher: Jim Sparkman
│  ├─ path: /home/shioya/work/konata/node_modules/riotcontrol
│  └─ licenseFile: node_modules/riotcontrol/LICENSE.txt
├─ roarr@2.15.4
│  ├─ licenses: BSD-3-Clause
│  ├─ repository: https://github.com/gajus/roarr
│  ├─ publisher: Gajus Kuizinas
│  ├─ email: gajus@gajus.com
│  ├─ url: http://gajus.com
│  ├─ path: /home/shioya/work/konata/node_modules/roarr
│  └─ licenseFile: node_modules/roarr/LICENSE
├─ rollup-pluginutils@2.8.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/rollup/rollup-pluginutils
│  ├─ publisher: Rich Harris
│  ├─ email: richard.a.harris@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/rollup-pluginutils
│  └─ licenseFile: node_modules/rollup-pluginutils/README.md
├─ rollup@0.57.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/rollup/rollup
│  ├─ publisher: Rich Harris
│  ├─ path: /home/shioya/work/konata/node_modules/rollup
│  └─ licenseFile: node_modules/rollup/LICENSE.md
├─ safe-buffer@5.1.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/feross/safe-buffer
│  ├─ publisher: Feross Aboukhadijeh
│  ├─ email: feross@feross.org
│  ├─ url: http://feross.org
│  ├─ path: /home/shioya/work/konata/node_modules/safe-buffer
│  └─ licenseFile: node_modules/safe-buffer/LICENSE
├─ safe-regex@1.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/substack/safe-regex
│  ├─ publisher: James Halliday
│  ├─ email: mail@substack.net
│  ├─ url: http://substack.net
│  ├─ path: /home/shioya/work/konata/node_modules/safe-regex
│  └─ licenseFile: node_modules/safe-regex/LICENSE
├─ semver-compare@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/substack/semver-compare
│  ├─ publisher: James Halliday
│  ├─ email: mail@substack.net
│  ├─ url: http://substack.net
│  ├─ path: /home/shioya/work/konata/node_modules/semver-compare
│  └─ licenseFile: node_modules/semver-compare/LICENSE
├─ semver@6.3.0
│  ├─ licenses: ISC
│  ├─ repository: https://github.com/npm/node-semver
│  ├─ path: /home/shioya/work/konata/node_modules/electron/node_modules/semver
│  └─ licenseFile: node_modules/electron/node_modules/semver/LICENSE
├─ semver@7.3.5
│  ├─ licenses: ISC
│  ├─ repository: https://github.com/npm/node-semver
│  ├─ path: /home/shioya/work/konata/node_modules/semver
│  └─ licenseFile: node_modules/semver/LICENSE
├─ serialize-error@7.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/serialize-error
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: https://sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/serialize-error
│  └─ licenseFile: node_modules/serialize-error/license
├─ set-value@0.4.3
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/set-value
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/union-value/node_modules/set-value
│  └─ licenseFile: node_modules/union-value/node_modules/set-value/LICENSE
├─ set-value@2.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/set-value
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/set-value
│  └─ licenseFile: node_modules/set-value/LICENSE
├─ signal-exit@3.0.2
│  ├─ licenses: ISC
│  ├─ repository: https://github.com/tapjs/signal-exit
│  ├─ publisher: Ben Coe
│  ├─ email: ben@npmjs.com
│  ├─ path: /home/shioya/work/konata/node_modules/signal-exit
│  └─ licenseFile: node_modules/signal-exit/LICENSE.txt
├─ simple-dom@1.3.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/ember-fastboot/simple-dom
│  ├─ publisher: Kris Selden
│  ├─ path: /home/shioya/work/konata/node_modules/simple-dom
│  └─ licenseFile: node_modules/simple-dom/README.md
├─ simple-html-tokenizer@0.5.7
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/tildeio/simple-html-tokenizer
│  ├─ path: /home/shioya/work/konata/node_modules/simple-html-tokenizer
│  └─ licenseFile: node_modules/simple-html-tokenizer/LICENSE
├─ skip-regex@0.3.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/aMarCruz/skip-regex
│  ├─ publisher: aMarCruz
│  ├─ email: amarcruz@yahoo.com
│  ├─ path: /home/shioya/work/konata/node_modules/skip-regex
│  └─ licenseFile: node_modules/skip-regex/LICENSE
├─ snapdragon-node@2.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/snapdragon-node
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/snapdragon-node
│  └─ licenseFile: node_modules/snapdragon-node/LICENSE
├─ snapdragon-util@3.0.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/snapdragon-util
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/snapdragon-util
│  └─ licenseFile: node_modules/snapdragon-util/LICENSE
├─ snapdragon@0.8.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/snapdragon
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/snapdragon
│  └─ licenseFile: node_modules/snapdragon/LICENSE
├─ source-map-resolve@0.5.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/lydell/source-map-resolve
│  ├─ publisher: Simon Lydell
│  ├─ path: /home/shioya/work/konata/node_modules/source-map-resolve
│  └─ licenseFile: node_modules/source-map-resolve/LICENSE
├─ source-map-url@0.4.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/lydell/source-map-url
│  ├─ publisher: Simon Lydell
│  ├─ path: /home/shioya/work/konata/node_modules/source-map-url
│  └─ licenseFile: node_modules/source-map-url/LICENSE
├─ source-map@0.5.7
│  ├─ licenses: BSD-3-Clause
│  ├─ repository: https://github.com/mozilla/source-map
│  ├─ publisher: Nick Fitzgerald
│  ├─ email: nfitzgerald@mozilla.com
│  ├─ path: /home/shioya/work/konata/node_modules/source-map
│  └─ licenseFile: node_modules/source-map/LICENSE
├─ source-map@0.7.3
│  ├─ licenses: BSD-3-Clause
│  ├─ repository: https://github.com/mozilla/source-map
│  ├─ publisher: Nick Fitzgerald
│  ├─ email: nfitzgerald@mozilla.com
│  ├─ path: /home/shioya/work/konata/node_modules/riot-compiler/node_modules/source-map
│  └─ licenseFile: node_modules/riot-compiler/node_modules/source-map/LICENSE
├─ sourcemap-codec@1.4.4
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/Rich-Harris/sourcemap-codec
│  ├─ publisher: Rich Harris
│  ├─ path: /home/shioya/work/konata/node_modules/sourcemap-codec
│  └─ licenseFile: node_modules/sourcemap-codec/LICENSE
├─ split-string@3.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/split-string
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/split-string
│  └─ licenseFile: node_modules/split-string/LICENSE
├─ sprintf-js@1.1.2
│  ├─ licenses: BSD-3-Clause
│  ├─ repository: https://github.com/alexei/sprintf.js
│  ├─ publisher: Alexandru Mărășteanu
│  ├─ email: hello@alexei.ro
│  ├─ path: /home/shioya/work/konata/node_modules/sprintf-js
│  └─ licenseFile: node_modules/sprintf-js/LICENSE
├─ static-extend@0.1.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/static-extend
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/static-extend
│  └─ licenseFile: node_modules/static-extend/LICENSE
├─ string-similarity@1.2.2
│  ├─ licenses: ISC
│  ├─ repository: https://github.com/aceakash/string-similarity
│  ├─ publisher: Akash Kurdekar
│  ├─ email: npm@kurdekar.com
│  ├─ url: http://untilfalse.com/
│  ├─ path: /home/shioya/work/konata/node_modules/string-similarity
│  └─ licenseFile: node_modules/string-similarity/README.md
├─ string_decoder@1.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/nodejs/string_decoder
│  ├─ path: /home/shioya/work/konata/node_modules/readdirp/node_modules/string_decoder
│  └─ licenseFile: node_modules/readdirp/node_modules/string_decoder/LICENSE
├─ sumchecker@3.0.1
│  ├─ licenses: Apache-2.0
│  ├─ repository: https://github.com/malept/sumchecker
│  ├─ publisher: Mark Lee
│  ├─ path: /home/shioya/work/konata/node_modules/sumchecker
│  └─ licenseFile: node_modules/sumchecker/LICENSE
├─ supports-color@5.5.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/chalk/supports-color
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/supports-color
│  └─ licenseFile: node_modules/supports-color/license
├─ time-zone@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/sindresorhus/time-zone
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/time-zone
│  └─ licenseFile: node_modules/time-zone/license
├─ to-object-path@0.3.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/to-object-path
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/to-object-path
│  └─ licenseFile: node_modules/to-object-path/LICENSE
├─ to-regex-range@2.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/micromatch/to-regex-range
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/to-regex-range
│  └─ licenseFile: node_modules/to-regex-range/LICENSE
├─ to-regex@3.0.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/to-regex
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/to-regex
│  └─ licenseFile: node_modules/to-regex/LICENSE
├─ type-check@0.3.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/gkz/type-check
│  ├─ publisher: George Zahariev
│  ├─ email: z@georgezahariev.com
│  ├─ path: /home/shioya/work/konata/node_modules/type-check
│  └─ licenseFile: node_modules/type-check/LICENSE
├─ type-fest@0.13.1
│  ├─ licenses: (MIT OR CC0-1.0)
│  ├─ repository: https://github.com/sindresorhus/type-fest
│  ├─ publisher: Sindre Sorhus
│  ├─ email: sindresorhus@gmail.com
│  ├─ url: https://sindresorhus.com
│  ├─ path: /home/shioya/work/konata/node_modules/type-fest
│  └─ licenseFile: node_modules/type-fest/license
├─ union-value@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/union-value
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/union-value
│  └─ licenseFile: node_modules/union-value/LICENSE
├─ universalify@0.1.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/RyanZim/universalify
│  ├─ publisher: Ryan Zimmerman
│  ├─ email: opensrc@ryanzim.com
│  ├─ path: /home/shioya/work/konata/node_modules/universalify
│  └─ licenseFile: node_modules/universalify/LICENSE
├─ unset-value@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/unset-value
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/unset-value
│  └─ licenseFile: node_modules/unset-value/LICENSE
├─ upath@1.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/anodynos/upath
│  ├─ publisher: Angelos Pikoulas
│  ├─ email: agelos.pikoulas@gmail.com
│  ├─ path: /home/shioya/work/konata/node_modules/upath
│  └─ licenseFile: node_modules/upath/LICENSE
├─ urix@0.1.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/lydell/urix
│  ├─ publisher: Simon Lydell
│  ├─ path: /home/shioya/work/konata/node_modules/urix
│  └─ licenseFile: node_modules/urix/LICENSE
├─ use@3.1.1
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/jonschlinkert/use
│  ├─ publisher: Jon Schlinkert
│  ├─ url: https://github.com/jonschlinkert
│  ├─ path: /home/shioya/work/konata/node_modules/use
│  └─ licenseFile: node_modules/use/LICENSE
├─ util-deprecate@1.0.2
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/TooTallNate/util-deprecate
│  ├─ publisher: Nathan Rajlich
│  ├─ email: nathan@tootallnate.net
│  ├─ url: http://n8.io/
│  ├─ path: /home/shioya/work/konata/node_modules/util-deprecate
│  └─ licenseFile: node_modules/util-deprecate/LICENSE
├─ wordwrap@1.0.0
│  ├─ licenses: MIT
│  ├─ repository: https://github.com/substack/node-wordwrap
│  ├─ publisher: James Halliday
│  ├─ email: mail@substack.net
│  ├─ url: http://substack.net
│  ├─ path: /home/shioya/work/konata/node_modules/wordwrap
│  └─ licenseFile: node_modules/wordwrap/LICENSE
├─ wrappy@1.0.2
│  ├─ licenses: ISC
│  ├─ repository: https://github.com/npm/wrappy
│  ├─ publisher: Isaac Z. Schlueter
│  ├─ email: i@izs.me
│  ├─ url: http://blog.izs.me/
│  ├─ path: /home/shioya/work/konata/node_modules/wrappy
│  └─ licenseFile: node_modules/wrappy/LICENSE
├─ yallist@4.0.0
│  ├─ licenses: ISC
│  ├─ repository: https://github.com/isaacs/yallist
│  ├─ publisher: Isaac Z. Schlueter
│  ├─ email: i@izs.me
│  ├─ url: http://blog.izs.me/
│  ├─ path: /home/shioya/work/konata/node_modules/yallist
│  └─ licenseFile: node_modules/yallist/LICENSE
└─ yauzl@2.10.0
   ├─ licenses: MIT
   ├─ repository: https://github.com/thejoshwolfe/yauzl
   ├─ publisher: Josh Wolfe
   ├─ email: thejoshwolfe@gmail.com
   ├─ path: /home/shioya/work/konata/node_modules/yauzl
   └─ licenseFile: node_modules/yauzl/LICENSE

